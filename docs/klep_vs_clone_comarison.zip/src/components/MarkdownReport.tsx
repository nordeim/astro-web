import type { ComponentPropsWithoutRef } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeSlug from "rehype-slug";
import { enhanceReportMarkdown } from "../lib/enhance";

const BADGE_STYLES: Record<string, string> = {
  critical: "bg-red-50 text-critical ring-1 ring-inset ring-red-200",
  high: "bg-amber-50 text-high ring-1 ring-inset ring-amber-200",
  medium: "bg-yellow-50 text-medium ring-1 ring-inset ring-yellow-200",
  low: "bg-lime-50 text-low ring-1 ring-inset ring-lime-200",
  informational: "bg-blue-50 text-info ring-1 ring-inset ring-blue-200",
  verified: "bg-teal-50 text-teal-700 ring-1 ring-inset ring-teal-200",
  reasoned: "bg-violet-50 text-violet-700 ring-1 ring-inset ring-violet-200",
  assumed: "bg-orange-50 text-orange-700 ring-1 ring-inset ring-orange-200",
  unverifiable: "bg-stone-100 text-stone-600 ring-1 ring-inset ring-stone-300",
};

function StatusBadge({ children }: { children: string }) {
  const key = children.trim().toLowerCase();
  const style = BADGE_STYLES[key];
  if (!style) {
    return (
      <code className="rounded bg-stone-100 px-1.5 py-0.5 font-mono text-[0.8em] text-stone-700">
        {children}
      </code>
    );
  }
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 font-sans text-xs font-semibold tracking-wide uppercase ${style}`}
    >
      {children}
    </span>
  );
}

export default function MarkdownReport({ markdown }: { markdown: string }) {
  const source = enhanceReportMarkdown(markdown);

  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      rehypePlugins={[rehypeSlug]}
      components={{
        h1: ({ children }: ComponentPropsWithoutRef<"h1">) => (
          <h1 className="mb-3 font-serif text-3xl font-semibold text-ink-900 sm:text-4xl">
            {children}
          </h1>
        ),
        h2: ({ id, children }: ComponentPropsWithoutRef<"h2">) => (
          <h2
            id={id}
            className="mt-14 scroll-mt-24 border-b border-paper-200 pb-3 font-serif text-2xl font-semibold text-ink-900 first:mt-0 sm:text-[1.75rem]"
          >
            {children}
          </h2>
        ),
        h3: ({ id, children }: ComponentPropsWithoutRef<"h3">) => (
          <h3 id={id} className="mt-10 scroll-mt-24 font-serif text-xl font-semibold text-ink-800">
            {children}
          </h3>
        ),
        p: ({ children }: ComponentPropsWithoutRef<"p">) => (
          <p className="mt-4 leading-relaxed text-stone-700 first:mt-0">{children}</p>
        ),
        a: ({ href, children }: ComponentPropsWithoutRef<"a">) => (
          <a
            href={href}
            target={href?.startsWith("http") ? "_blank" : undefined}
            rel={href?.startsWith("http") ? "noopener noreferrer" : undefined}
            className="font-medium text-teal-700 underline decoration-teal-300 decoration-2 underline-offset-2 transition hover:text-teal-600 hover:decoration-teal-500"
          >
            {children}
          </a>
        ),
        strong: ({ children }: ComponentPropsWithoutRef<"strong">) => (
          <strong className="font-semibold text-ink-900">{children}</strong>
        ),
        em: ({ children }: ComponentPropsWithoutRef<"em">) => (
          <em className="text-stone-600">{children}</em>
        ),
        ul: ({ children }: ComponentPropsWithoutRef<"ul">) => (
          <ul className="mt-4 list-disc space-y-2 pl-6 marker:text-teal-600">{children}</ul>
        ),
        ol: ({ children }: ComponentPropsWithoutRef<"ol">) => (
          <ol className="mt-4 list-decimal space-y-2 pl-6 marker:font-semibold marker:text-teal-700">
            {children}
          </ol>
        ),
        li: ({ children }: ComponentPropsWithoutRef<"li">) => (
          <li className="leading-relaxed text-stone-700">{children}</li>
        ),
        hr: () => <hr className="my-12 border-t border-paper-200" />,
        blockquote: ({ children }: ComponentPropsWithoutRef<"blockquote">) => (
          <blockquote className="mt-4 border-l-4 border-moss-500 bg-paper-100 py-2 pl-5 pr-4 italic text-stone-700">
            {children}
          </blockquote>
        ),
        code: ({ children }: ComponentPropsWithoutRef<"code">) => {
          const text = String(children);
          return <StatusBadge>{text}</StatusBadge>;
        },
        pre: ({ children }: ComponentPropsWithoutRef<"pre">) => (
          <pre className="mt-4 overflow-x-auto rounded-lg bg-ink-900 p-4 font-mono text-sm text-paper-100">
            {children}
          </pre>
        ),
        table: ({ children }: ComponentPropsWithoutRef<"table">) => (
          <div className="mt-6 overflow-x-auto rounded-lg border border-paper-200">
            <table className="w-full min-w-[560px] border-collapse text-left text-sm">
              {children}
            </table>
          </div>
        ),
        thead: ({ children }: ComponentPropsWithoutRef<"thead">) => (
          <thead className="bg-ink-900 text-paper-50">{children}</thead>
        ),
        tbody: ({ children }: ComponentPropsWithoutRef<"tbody">) => (
          <tbody className="divide-y divide-paper-200 bg-white">{children}</tbody>
        ),
        tr: ({ children }: ComponentPropsWithoutRef<"tr">) => (
          <tr className="even:bg-paper-50/70">{children}</tr>
        ),
        th: ({ children }: ComponentPropsWithoutRef<"th">) => (
          <th className="px-4 py-3 font-serif text-sm font-semibold whitespace-nowrap">
            {children}
          </th>
        ),
        td: ({ children }: ComponentPropsWithoutRef<"td">) => (
          <td className="px-4 py-3 align-top text-stone-700">{children}</td>
        ),
      }}
    >
      {source}
    </ReactMarkdown>
  );
}
