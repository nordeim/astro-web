import type { TocItem } from "../lib/toc";

function TocLink({ item, onNavigate }: { item: TocItem; onNavigate?: () => void }) {
  return (
    <li>
      <a
        href={`#${item.slug}`}
        onClick={onNavigate}
        className="block rounded-md px-2.5 py-1.5 text-sm text-stone-600 transition hover:bg-teal-600/10 hover:text-teal-700"
      >
        {item.text}
      </a>
      {item.children.length > 0 && (
        <ul className="mt-0.5 ml-3 space-y-0.5 border-l border-paper-200 pl-2">
          {item.children.map((child) => (
            <li key={child.slug}>
              <a
                href={`#${child.slug}`}
                onClick={onNavigate}
                className="block rounded-md px-2.5 py-1 text-[0.8rem] text-stone-500 transition hover:bg-teal-600/10 hover:text-teal-700"
              >
                {child.text}
              </a>
            </li>
          ))}
        </ul>
      )}
    </li>
  );
}

export default function TableOfContents({
  items,
  onNavigate,
}: {
  items: TocItem[];
  onNavigate?: () => void;
}) {
  return (
    <nav aria-label="Report sections">
      <p className="px-2.5 font-mono text-xs font-semibold tracking-widest text-stone-400 uppercase">
        Contents
      </p>
      <ul className="mt-2 space-y-0.5">
        {items.map((item) => (
          <TocLink key={item.slug} item={item} onNavigate={onNavigate} />
        ))}
      </ul>
    </nav>
  );
}
