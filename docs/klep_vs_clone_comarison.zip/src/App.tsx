import { useMemo, useState } from "react";
import { ExternalLink, Menu, X } from "lucide-react";
import reportMarkdown from "./content/comparative-analysis.md?raw";
import MarkdownReport from "./components/MarkdownReport";
import TableOfContents from "./components/TableOfContents";
import { buildToc } from "./lib/toc";

const SITES = [
  { label: "Original — kelp.agency", url: "https://www.kelp.agency/" },
  { label: "Clone — astro.jesspete.shop", url: "https://astro.jesspete.shop/" },
];

export default function App() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const toc = useMemo(() => buildToc(reportMarkdown), []);

  return (
    <div className="min-h-screen bg-paper-50 text-stone-900">
      <a
        href="#report-start"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:rounded focus:bg-ink-900 focus:px-3 focus:py-2 focus:text-white"
      >
        Skip to report content
      </a>

      <header className="sticky top-0 z-40 border-b border-ink-800/10 bg-ink-950 text-paper-50">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
          <button
            type="button"
            onClick={() => setDrawerOpen(true)}
            className="rounded-md p-2 text-paper-100 transition hover:bg-white/10 lg:hidden"
            aria-label="Open table of contents"
          >
            <Menu className="h-5 w-5" aria-hidden="true" />
          </button>

          <div className="flex min-w-0 flex-1 items-center gap-3">
            <span
              className="hidden h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-teal-600 to-moss-600 font-serif text-sm font-bold text-white sm:flex"
              aria-hidden="true"
            >
              UX
            </span>
            <div className="min-w-0">
              <p className="truncate font-serif text-base font-semibold leading-tight sm:text-lg">
                Kelp Creative Agency — Comparative UI/UX Audit
              </p>
              <p className="truncate font-mono text-[0.7rem] tracking-wide text-teal-300/90 uppercase">
                Original vs. Clone · Visual &amp; Design Review
              </p>
            </div>
          </div>

          <nav className="hidden shrink-0 items-center gap-2 sm:flex" aria-label="Reference sites">
            {SITES.map((site) => (
              <a
                key={site.url}
                href={site.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-medium text-paper-100 transition hover:border-teal-400/60 hover:bg-white/10"
              >
                {site.label}
                <ExternalLink className="h-3 w-3" aria-hidden="true" />
              </a>
            ))}
          </nav>
        </div>
      </header>

      {drawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            aria-label="Close table of contents"
            onClick={() => setDrawerOpen(false)}
            className="absolute inset-0 bg-ink-950/60"
          />
          <div className="absolute inset-y-0 left-0 w-72 max-w-[85vw] overflow-y-auto bg-paper-50 p-4 shadow-xl">
            <div className="mb-2 flex items-center justify-between">
              <span className="font-mono text-xs font-semibold tracking-widest text-stone-400 uppercase">
                Menu
              </span>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="rounded-md p-1.5 text-stone-500 hover:bg-stone-100"
                aria-label="Close"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>
            <div className="mb-4 flex flex-col gap-2">
              {SITES.map((site) => (
                <a
                  key={site.url}
                  href={site.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-between rounded-lg border border-stone-200 bg-white px-3 py-2 text-sm font-medium text-stone-700"
                >
                  {site.label}
                  <ExternalLink className="h-3.5 w-3.5 text-stone-400" aria-hidden="true" />
                </a>
              ))}
            </div>
            <TableOfContents items={toc} onNavigate={() => setDrawerOpen(false)} />
          </div>
        </div>
      )}

      <div className="mx-auto flex max-w-6xl gap-8 px-4 py-8 sm:px-6 lg:py-12">
        <aside className="hidden w-64 shrink-0 lg:block">
          <div className="sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto rounded-xl border border-paper-200 bg-white/60 p-3">
            <TableOfContents items={toc} />
          </div>
        </aside>

        <main id="report-start" className="min-w-0 flex-1">
          <div className="mb-8 rounded-2xl border border-paper-200 bg-white p-5 shadow-sm sm:p-6">
            <p className="font-mono text-xs font-semibold tracking-widest text-teal-700 uppercase">
              Mode C · Audit / Review Report
            </p>
            <h1 className="mt-2 font-serif text-2xl font-bold text-ink-900 sm:text-3xl">
              Does the clone hold up against the original?
            </h1>
            <p className="mt-2 max-w-3xl text-sm leading-relaxed text-stone-600 sm:text-base">
              A structural, content, and information-architecture comparison of{" "}
              <span className="font-medium text-ink-800">kelp.agency</span> and its clone at{" "}
              <span className="font-medium text-ink-800">astro.jesspete.shop</span>, with every
              claim tagged by how it was verified.
            </p>
            <div className="mt-4 flex flex-wrap gap-2 sm:hidden">
              {SITES.map((site) => (
                <a
                  key={site.url}
                  href={site.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-full border border-stone-200 bg-paper-50 px-3 py-1.5 text-xs font-medium text-stone-700"
                >
                  {site.label}
                  <ExternalLink className="h-3 w-3" aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>

          <article className="rounded-2xl border border-paper-200 bg-white p-5 shadow-sm sm:p-8 lg:p-10">
            <MarkdownReport markdown={reportMarkdown} />
          </article>

          <footer className="mt-10 pb-4 text-center text-xs text-stone-400">
            Comparative audit report · generated from live retrieval of both sites · findings
            labeled Verified / Reasoned / Assumed / Unverifiable per evidence available at time of
            review.
          </footer>
        </main>
      </div>
    </div>
  );
}
