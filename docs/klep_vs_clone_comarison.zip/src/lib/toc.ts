import GithubSlugger from "github-slugger";

export interface TocItem {
  level: 2 | 3;
  text: string;
  slug: string;
  children: TocItem[];
}

/**
 * Extracts an H2/H3 outline from markdown source, nesting H3 items under the
 * preceding H2. Slugs match rehype-slug's github-slugger output so anchor
 * links line up with the heading ids react-markdown renders.
 */
export function buildToc(markdown: string): TocItem[] {
  const slugger = new GithubSlugger();
  const lines = markdown.split("\n");
  const toc: TocItem[] = [];
  let current: TocItem | null = null;

  for (const line of lines) {
    const h2 = /^##\s+(.+?)\s*$/.exec(line);
    const h3 = /^###\s+(.+?)\s*$/.exec(line);

    if (h2) {
      const text = h2[1].replace(/`/g, "");
      current = { level: 2, text, slug: slugger.slug(text), children: [] };
      toc.push(current);
    } else if (h3) {
      const text = h3[1].replace(/`/g, "");
      const item: TocItem = { level: 3, text, slug: slugger.slug(text), children: [] };
      if (current) current.children.push(item);
      else toc.push(item);
    }
  }

  return toc;
}
