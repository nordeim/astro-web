/**
 * Wraps the value portion of "- **Severity:** X" / "- **Confidence:** X"
 * bullet lines in inline-code so the markdown renderer can style them as
 * status badges without hand-rolling a custom block syntax.
 */
export function enhanceReportMarkdown(markdown: string): string {
  return markdown.replace(
    /^(\s*-\s*\*\*(?:Severity|Confidence):\*\*)\s+(.+)$/gm,
    (_match, label: string, value: string) => `${label} \`${value.trim()}\``,
  );
}
